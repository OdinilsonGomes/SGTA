<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="Sistema de Gerenciamento de Turmas e Alunos">
<meta name="author" content="Desafio pratico programador Full Stack">

<link rel="icon" type="image/png" href="../img/global/favicon.ico"/>

<!-- Bootstrap CSS 4 -->
<!-- link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"-->
<link rel="stylesheet" href="plugins/bootstrap/css/bootstrap.min.css">
<!-- Font Awesome -->
<link rel="stylesheet" href="plugins/fontawesome-free-5.13.0-web/css/all.css">
<!-- Datatables CSS -->
<link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css"> 
<!-- Custom styles for this template -->
<link href="osc.css" rel="stylesheet">
<!-- Bootstrap Theme CSS 3 -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap-theme.min.css">