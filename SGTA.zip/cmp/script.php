<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<!-- jQuery -->
<!-- script src="https://code.jquery.com/jquery-3.5.1.min.js"></script -->
	<script src="plugins/jquery-3.5.1.min.js"></script>
	<!--script src="plugins/jquery-2.0.3.min.js"></script -->

<!-- Bootstrap 4 <script src="../dist/js/bootstrap.min.js"></script> -->
<script src="plugins/bootstrap/js/bootstrap.min.js"></script>
<!--script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script-->
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<link rel="stylesheet" href="js/jquery-ui-themes-1.12.1/themes/south-street/jquery-ui.css">
	
<!--
	<script src="js/libray.js"></script>
	<script src="js/dialogojs1.js"></script>
-->
<link rel="stylesheet" href="plugins/chosen/chosen.min.css" />
<!-- END BODY-->
<script src="plugins/inputlimiter/jquery.inputlimiter.1.3.1.min.js"></script>
<script src="plugins/chosen/chosen.jquery.min.js"></script>
<script src="plugins/tagsinput/jquery.tagsinput.min.js"></script>
	<!--script src="assets/plugins/pace/pace.js"></script-->
<script src="plugins/autosize/jquery.autosize.min.js"></script>
<script src="js/formsInit.js"> </script>


	
	
<!-- Popper -->
<!--script src="../assets/js/vendor/popper.min.js"></script>
<!-- Holder -->

<script src="js/main.js"></script>
