<footer class="main-footer">
    <div class="copyright text-center my-auto">
        <hr />
        <span>Odinilson Gomes &copy; Todos os direitos reservados 2022</span>
    </div>
</footer>
<?php
    require_once("cmp/modal_main.php");
?>