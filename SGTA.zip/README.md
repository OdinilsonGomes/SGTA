# Desafio de Gerenciamento de Turma e Alunos

---------------  API ------------------------
<h2>RO1 - Cadastro de turmas</h2>
    http://localhost/sgta/servicos/cms.php?action=insertTurma
        

